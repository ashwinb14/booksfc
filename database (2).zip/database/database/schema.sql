-- Accounting System Database Schema
-- This file is for reference. Tables are created automatically by the plugin.

-- Transactions Table
CREATE TABLE IF NOT EXISTS wp_accounting_transactions (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    transaction_type varchar(50) NOT NULL,
    transaction_date date NOT NULL,
    amount decimal(15,2) NOT NULL,
    currency varchar(10) DEFAULT 'INR',
    reference_id bigint(20) DEFAULT NULL,
    reference_type varchar(50) DEFAULT NULL,
    customer_id bigint(20) DEFAULT NULL,
    vendor_id bigint(20) DEFAULT NULL,
    description text,
    status varchar(50) DEFAULT 'pending',
    created_by bigint(20) NOT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY transaction_type (transaction_type),
    KEY transaction_date (transaction_date),
    KEY customer_id (customer_id),
    KEY vendor_id (vendor_id),
    KEY reference_id (reference_id, reference_type)
);

-- Ledger Table
CREATE TABLE IF NOT EXISTS wp_accounting_ledger (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    transaction_id bigint(20) NOT NULL,
    account_type varchar(50) NOT NULL,
    account_id bigint(20) DEFAULT NULL,
    debit decimal(15,2) DEFAULT 0.00,
    credit decimal(15,2) DEFAULT 0.00,
    balance decimal(15,2) DEFAULT 0.00,
    description text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY transaction_id (transaction_id),
    KEY account_type (account_type),
    KEY account_id (account_id)
);

-- Invoice Items Table
CREATE TABLE IF NOT EXISTS wp_accounting_invoice_items (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    invoice_id bigint(20) NOT NULL,
    product_id bigint(20) DEFAULT NULL,
    item_name varchar(255) NOT NULL,
    description text,
    quantity decimal(10,2) NOT NULL DEFAULT 1.00,
    unit_price decimal(15,2) NOT NULL,
    discount decimal(15,2) DEFAULT 0.00,
    tax_rate decimal(5,2) DEFAULT 0.00,
    tax_amount decimal(15,2) DEFAULT 0.00,
    total decimal(15,2) NOT NULL,
    hsn_code varchar(50) DEFAULT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY invoice_id (invoice_id),
    KEY product_id (product_id)
);

-- Payments Table
CREATE TABLE IF NOT EXISTS wp_accounting_payments (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    payment_type varchar(50) NOT NULL,
    payment_method varchar(50) NOT NULL,
    amount decimal(15,2) NOT NULL,
    payment_date date NOT NULL,
    reference_id bigint(20) DEFAULT NULL,
    reference_type varchar(50) DEFAULT NULL,
    customer_id bigint(20) DEFAULT NULL,
    vendor_id bigint(20) DEFAULT NULL,
    transaction_id varchar(255) DEFAULT NULL,
    upi_id varchar(255) DEFAULT NULL,
    notes text,
    status varchar(50) DEFAULT 'completed',
    created_by bigint(20) NOT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY payment_type (payment_type),
    KEY payment_date (payment_date),
    KEY customer_id (customer_id),
    KEY vendor_id (vendor_id),
    KEY reference_id (reference_id, reference_type)
);

-- Bank Reconciliation Table
CREATE TABLE IF NOT EXISTS wp_accounting_bank_reconciliation (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    bank_account_id bigint(20) NOT NULL,
    transaction_date date NOT NULL,
    transaction_type varchar(50) NOT NULL,
    amount decimal(15,2) NOT NULL,
    description text,
    reference_number varchar(255) DEFAULT NULL,
    statement_balance decimal(15,2) DEFAULT NULL,
    reconciled tinyint(1) DEFAULT 0,
    reconciled_date datetime DEFAULT NULL,
    payment_id bigint(20) DEFAULT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY bank_account_id (bank_account_id),
    KEY transaction_date (transaction_date),
    KEY reconciled (reconciled)
);

-- Inventory Stock Table
CREATE TABLE IF NOT EXISTS wp_accounting_inventory_stock (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    product_id bigint(20) NOT NULL,
    movement_type varchar(50) NOT NULL,
    quantity decimal(10,2) NOT NULL,
    reference_id bigint(20) DEFAULT NULL,
    reference_type varchar(50) DEFAULT NULL,
    unit_cost decimal(15,2) DEFAULT NULL,
    notes text,
    created_by bigint(20) NOT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY product_id (product_id),
    KEY movement_type (movement_type),
    KEY reference_id (reference_id, reference_type)
);

-- Customer Balance Table
CREATE TABLE IF NOT EXISTS wp_accounting_customer_balance (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    customer_id bigint(20) NOT NULL,
    total_invoiced decimal(15,2) DEFAULT 0.00,
    total_paid decimal(15,2) DEFAULT 0.00,
    outstanding_balance decimal(15,2) DEFAULT 0.00,
    last_transaction_date datetime DEFAULT NULL,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY customer_id (customer_id)
);

-- Vendor Balance Table
CREATE TABLE IF NOT EXISTS wp_accounting_vendor_balance (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    vendor_id bigint(20) NOT NULL,
    total_billed decimal(15,2) DEFAULT 0.00,
    total_paid decimal(15,2) DEFAULT 0.00,
    outstanding_balance decimal(15,2) DEFAULT 0.00,
    last_transaction_date datetime DEFAULT NULL,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY vendor_id (vendor_id)
);

-- Invoice Templates Table
CREATE TABLE IF NOT EXISTS wp_accounting_invoice_templates (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    template_name varchar(255) NOT NULL,
    is_default tinyint(1) DEFAULT 0,
    template_data longtext,
    created_by bigint(20) NOT NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY is_default (is_default)
);

